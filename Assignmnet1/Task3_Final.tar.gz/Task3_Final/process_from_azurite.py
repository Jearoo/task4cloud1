from azure.storage.blob import BlobServiceClient
import pandas as pd
import io, json, os

CONNECT_STR = "UseDevelopmentStorage=true"
CONTAINER = "datasets"
BLOB_NAME = "All_Diets.csv"
OUT_PATH = os.path.expanduser("~/task3/simulated_nosql/results.json")

def process_nutritional_data_from_azurite():
    bsc = BlobServiceClient.from_connection_string(CONNECT_STR)
    cc = bsc.get_container_client(CONTAINER)
    bc = cc.get_blob_client(BLOB_NAME)

    stream = bc.download_blob().readall()
    df = pd.read_csv(io.BytesIO(stream))

    avg_macros = df.groupby("Diet_type")[["Protein(g)", "Carbs(g)", "Fat(g)"]].mean().round(2)
    result = avg_macros.reset_index().to_dict(orient="records")

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, "w") as f:
        json.dump(result, f, indent=2)

    print("✅ Processed data from Azurite")
    print("✅ Wrote:", OUT_PATH)
    print("✅ Rows:", len(result))

process_nutritional_data_from_azurite()
