from azure.storage.blob import BlobServiceClient
import os
CONNECT_STR = "UseDevelopmentStorage=true"

CONTAINER = "datasets"
BLOB_NAME = "All_Diets.csv"
LOCAL_FILE = os.path.expanduser("~/task3/All_Diets.csv")

bsc = BlobServiceClient.from_connection_string(CONNECT_STR)
cc = bsc.get_container_client(CONTAINER)

try:
    cc.create_container()
    print("✅ Created container:", CONTAINER)
except Exception:
    print("ℹ️ Container already exists:", CONTAINER)

bc = cc.get_blob_client(BLOB_NAME)
with open(LOCAL_FILE, "rb") as f:
    bc.upload_blob(f, overwrite=True)

print(f"✅ Uploaded {LOCAL_FILE} -> {CONTAINER}/{BLOB_NAME}")
print("✅ Blob size (bytes):", bc.get_blob_properties().size)
